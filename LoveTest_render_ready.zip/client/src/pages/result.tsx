import { useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/Header";
import ResultDisplay from "@/components/ResultDisplay";
import type { TestResult } from "@shared/schema";

export default function Result() {
  const [, setLocation] = useLocation();
  const searchString = useSearch();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const params = new URLSearchParams(searchString);
  const testId = params.get("id");

  useEffect(() => {
    document.title = "Résultat - Test de Compatibilité";
  }, []);

  const { data: testResult, isLoading, error } = useQuery<TestResult>({
    queryKey: ["/api/test", testId],
    enabled: !!testId,
    retry: false,
  });

  useEffect(() => {
    if (error) {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Session expirée",
          description: "Vous allez être redirigé vers la page de connexion...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      
      toast({
        title: "Erreur",
        description: "Impossible de charger le résultat du test.",
        variant: "destructive",
      });
      setLocation("/test");
    }
  }, [error, toast, setLocation]);

  if (!testId) {
    setLocation("/test");
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header
          userName={user?.firstName || user?.email || "Utilisateur"}
          userEmail={user?.email || ""}
          onLogout={() => window.location.href = "/api/logout"}
          onViewProfile={() => console.log("Profile")}
          onViewHistory={() => setLocation("/history")}
        />
        <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 mx-auto border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-lg text-muted-foreground">Chargement du résultat...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!testResult) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header
        userName={user?.firstName || user?.email || "Utilisateur"}
        userEmail={user?.email || ""}
        onLogout={() => window.location.href = "/api/logout"}
        onViewProfile={() => console.log("Profile")}
        onViewHistory={() => setLocation("/history")}
      />
      <ResultDisplay
        result={testResult.result as "accepted" | "refused"}
        maleFirstName={testResult.maleFirstName}
        femaleFirstName={testResult.femaleFirstName}
        onNewTest={() => setLocation("/test")}
        onViewHistory={() => setLocation("/history")}
      />
    </div>
  );
}
