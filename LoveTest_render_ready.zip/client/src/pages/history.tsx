import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/Header";
import HistoryPage from "@/components/HistoryPage";
import type { TestResult } from "@shared/schema";

export default function History() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    document.title = "Historique - Test de Compatibilité";
  }, []);

  const { data: results = [], isLoading, error } = useQuery<TestResult[]>({
    queryKey: ["/api/test/history"],
    retry: false,
  });

  useEffect(() => {
    if (error) {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Session expirée",
          description: "Vous allez être redirigé vers la page de connexion...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      
      toast({
        title: "Erreur",
        description: "Impossible de charger l'historique.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const formattedResults = results.map((result) => ({
    id: result.id,
    maleFirstName: result.maleFirstName,
    femaleFirstName: result.femaleFirstName,
    result: result.result as "accepted" | "refused",
    date: new Date(result.createdAt).toLocaleDateString("fr-FR", {
      day: "numeric",
      month: "long",
      year: "numeric"
    }),
  }));

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header
          userName={user?.firstName || user?.email || "Utilisateur"}
          userEmail={user?.email || ""}
          onLogout={() => window.location.href = "/api/logout"}
          onViewProfile={() => console.log("Profile")}
          onViewHistory={() => setLocation("/history")}
        />
        <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 mx-auto border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-lg text-muted-foreground">Chargement de l'historique...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header
        userName={user?.firstName || user?.email || "Utilisateur"}
        userEmail={user?.email || ""}
        onLogout={() => window.location.href = "/api/logout"}
        onViewProfile={() => console.log("Profile")}
        onViewHistory={() => setLocation("/history")}
      />
      <HistoryPage
        results={formattedResults}
        onBack={() => setLocation("/test")}
        onViewResult={(id) => setLocation(`/result?id=${id}`)}
      />
    </div>
  );
}
