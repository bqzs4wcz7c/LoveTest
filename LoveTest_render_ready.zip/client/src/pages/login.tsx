import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart } from "lucide-react";
import { SiGoogle } from "react-icons/si";

export default function Login() {
  useEffect(() => {
    document.title = "Connexion - Test de Compatibilité";
  }, []);

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/20 via-secondary/20 to-primary/30 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(255,105,180,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(139,92,246,0.1),transparent_50%)]" />
      
      <Card className="w-full max-w-md relative z-10 shadow-2xl">
        <CardHeader className="space-y-4 text-center pb-8">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
            <Heart className="w-8 h-8 text-white fill-white" data-testid="icon-heart-logo" />
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent" data-testid="text-title">
            Test de Compatibilité
          </CardTitle>
          <CardDescription className="text-base" data-testid="text-description">
            Découvrez si vous êtes faits l'un pour l'autre
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <Button
            onClick={handleLogin}
            size="lg"
            className="w-full h-14 text-base font-semibold bg-gradient-to-r from-primary to-secondary hover-elevate active-elevate-2"
            data-testid="button-login"
          >
            <SiGoogle className="w-5 h-5 mr-3" />
            Se connecter avec Google
          </Button>

          <p className="text-center text-sm text-muted-foreground" data-testid="text-info">
            Connexion sécurisée avec votre compte Google
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
