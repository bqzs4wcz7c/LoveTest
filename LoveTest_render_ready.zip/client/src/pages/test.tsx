import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/Header";
import TestForm from "@/components/TestForm";

function calculateCompatibility(data: any): "accepted" | "refused" {
  const maleSum = data.male.firstName.length + parseInt(data.male.age) + data.male.month.length;
  const femaleSum = data.female.firstName.length + parseInt(data.female.age) + data.female.month.length;
  const total = maleSum + femaleSum;
  
  return total % 2 === 0 ? "accepted" : "refused";
}

export default function Test() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    document.title = "Test de Compatibilité";
  }, []);

  const submitTestMutation = useMutation({
    mutationFn: async (data: any) => {
      const result = calculateCompatibility(data);
      
      const response = await apiRequest("POST", "/api/test/submit", {
        maleFirstName: data.male.firstName,
        maleAge: parseInt(data.male.age),
        maleMonth: data.male.month,
        femaleFirstName: data.female.firstName,
        femaleAge: parseInt(data.female.age),
        femaleMonth: data.female.month,
        result: result,
      });
      
      const jsonData = await response.json();
      return jsonData;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/test/history"] });
      setLocation(`/result?id=${data.id}`);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Vous allez être redirigé vers la page de connexion...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la soumission du test.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: any) => {
    submitTestMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        userName={user?.firstName || user?.email || "Utilisateur"}
        userEmail={user?.email || ""}
        onLogout={() => window.location.href = "/api/logout"}
        onViewProfile={() => console.log("Profile")}
        onViewHistory={() => setLocation("/history")}
      />
      <TestForm onSubmit={handleSubmit} />
      
      {submitTestMutation.isPending && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-card p-8 rounded-lg shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 mx-auto border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-lg font-semibold">Calcul de la compatibilité...</p>
          </div>
        </div>
      )}
    </div>
  );
}
