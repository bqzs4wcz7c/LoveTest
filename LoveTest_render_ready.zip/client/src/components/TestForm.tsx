import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Heart, Sparkles } from "lucide-react";

const MONTHS = [
  "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
  "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
];

interface TestFormProps {
  onSubmit: (data: {
    male: { firstName: string; age: string; month: string };
    female: { firstName: string; age: string; month: string };
  }) => void;
}

export default function TestForm({ onSubmit }: TestFormProps) {
  const [maleFirstName, setMaleFirstName] = useState("");
  const [maleAge, setMaleAge] = useState("");
  const [maleMonth, setMaleMonth] = useState("");
  
  const [femaleFirstName, setFemaleFirstName] = useState("");
  const [femaleAge, setFemaleAge] = useState("");
  const [femaleMonth, setFemaleMonth] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      male: { firstName: maleFirstName, age: maleAge, month: maleMonth },
      female: { firstName: femaleFirstName, age: femaleAge, month: femaleMonth }
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/30 to-background p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center space-y-3 pt-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent" data-testid="text-form-title">
            Test de Compatibilité
          </h1>
          <p className="text-lg text-muted-foreground" data-testid="text-form-subtitle">
            Remplissez les informations pour découvrir votre compatibilité
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-gradient-to-br from-secondary/5 to-secondary/10 border-secondary/20">
              <CardHeader className="space-y-2">
                <CardTitle className="text-2xl font-semibold text-secondary flex items-center gap-2" data-testid="text-male-section">
                  <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center">
                    <span className="text-xl">👨</span>
                  </div>
                  Homme
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="male-firstname" className="text-sm font-medium">
                    Prénom
                  </Label>
                  <Input
                    id="male-firstname"
                    value={maleFirstName}
                    onChange={(e) => setMaleFirstName(e.target.value)}
                    placeholder="Jean"
                    className="h-12 bg-background/50"
                    data-testid="input-male-firstname"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="male-age" className="text-sm font-medium">
                    Âge
                  </Label>
                  <Input
                    id="male-age"
                    type="number"
                    min="18"
                    max="100"
                    value={maleAge}
                    onChange={(e) => setMaleAge(e.target.value)}
                    placeholder="25"
                    className="h-12 bg-background/50"
                    data-testid="input-male-age"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="male-month" className="text-sm font-medium">
                    Mois de naissance
                  </Label>
                  <Select value={maleMonth} onValueChange={setMaleMonth} required>
                    <SelectTrigger className="h-12 bg-background/50" data-testid="select-male-month">
                      <SelectValue placeholder="Sélectionner un mois" />
                    </SelectTrigger>
                    <SelectContent>
                      {MONTHS.map((month) => (
                        <SelectItem key={month} value={month}>
                          {month}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <CardHeader className="space-y-2">
                <CardTitle className="text-2xl font-semibold text-primary flex items-center gap-2" data-testid="text-female-section">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-xl">👩</span>
                  </div>
                  Femme
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="female-firstname" className="text-sm font-medium">
                    Prénom
                  </Label>
                  <Input
                    id="female-firstname"
                    value={femaleFirstName}
                    onChange={(e) => setFemaleFirstName(e.target.value)}
                    placeholder="Marie"
                    className="h-12 bg-background/50"
                    data-testid="input-female-firstname"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="female-age" className="text-sm font-medium">
                    Âge
                  </Label>
                  <Input
                    id="female-age"
                    type="number"
                    min="18"
                    max="100"
                    value={femaleAge}
                    onChange={(e) => setFemaleAge(e.target.value)}
                    placeholder="23"
                    className="h-12 bg-background/50"
                    data-testid="input-female-age"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="female-month" className="text-sm font-medium">
                    Mois de naissance
                  </Label>
                  <Select value={femaleMonth} onValueChange={setFemaleMonth} required>
                    <SelectTrigger className="h-12 bg-background/50" data-testid="select-female-month">
                      <SelectValue placeholder="Sélectionner un mois" />
                    </SelectTrigger>
                    <SelectContent>
                      {MONTHS.map((month) => (
                        <SelectItem key={month} value={month}>
                          {month}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-center pt-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg">
              <Heart className="w-8 h-8 text-white fill-white animate-pulse" data-testid="icon-heart-divider" />
            </div>
          </div>

          <div className="flex justify-center">
            <Button
              type="submit"
              size="lg"
              className="px-12 h-14 text-lg font-semibold bg-gradient-to-r from-primary via-secondary to-primary bg-size-200 hover:bg-pos-100 transition-all duration-500 shadow-lg hover-elevate active-elevate-2"
              data-testid="button-submit-test"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Calculer la Compatibilité
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
