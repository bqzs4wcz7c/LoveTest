import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2, XCircle, Heart, RotateCcw, History } from "lucide-react";

interface ResultDisplayProps {
  result: "accepted" | "refused";
  maleFirstName: string;
  femaleFirstName: string;
  onNewTest: () => void;
  onViewHistory: () => void;
}

export default function ResultDisplay({
  result,
  maleFirstName,
  femaleFirstName,
  onNewTest,
  onViewHistory
}: ResultDisplayProps) {
  const isAccepted = result === "accepted";

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-background via-accent/30 to-background">
      <div className="w-full max-w-3xl space-y-8">
        <Card className="shadow-2xl relative overflow-hidden">
          <div
            className={`absolute inset-0 opacity-10 ${
              isAccepted
                ? "bg-gradient-to-br from-green-400 to-green-600"
                : "bg-gradient-to-br from-red-400 to-red-600"
            }`}
          />
          
          <CardContent className="relative p-12 space-y-8">
            <div className="text-center space-y-6">
              {isAccepted ? (
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-green-100 dark:bg-green-950 flex items-center justify-center">
                    <CheckCircle2 className="w-16 h-16 text-green-600 dark:text-green-400" data-testid="icon-result-accepted" />
                  </div>
                </div>
              ) : (
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-red-100 dark:bg-red-950 flex items-center justify-center">
                    <XCircle className="w-16 h-16 text-red-600 dark:text-red-400" data-testid="icon-result-refused" />
                  </div>
                </div>
              )}

              <h1
                className={`text-6xl md:text-7xl font-extrabold ${
                  isAccepted ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
                }`}
                data-testid="text-result-status"
              >
                {isAccepted ? "ACCEPTÉ" : "REFUSÉ"}
              </h1>

              <div className="space-y-3">
                <p className="text-2xl font-semibold text-foreground" data-testid="text-result-names">
                  {maleFirstName} & {femaleFirstName}
                </p>
                
                {isAccepted ? (
                  <div className="space-y-2">
                    <p className="text-lg text-muted-foreground" data-testid="text-result-message">
                      Félicitations ! Vous êtes compatibles !
                    </p>
                    <div className="flex justify-center gap-2">
                      <Heart className="w-5 h-5 text-primary fill-primary animate-pulse" />
                      <Heart className="w-5 h-5 text-secondary fill-secondary animate-pulse delay-100" />
                      <Heart className="w-5 h-5 text-primary fill-primary animate-pulse delay-200" />
                    </div>
                    <p className="text-base text-muted-foreground max-w-md mx-auto">
                      Votre relation a toutes les chances de réussir. Les étoiles sont alignées en votre faveur !
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-lg text-muted-foreground" data-testid="text-result-message">
                      Malheureusement, la compatibilité n'est pas optimale.
                    </p>
                    <p className="text-base text-muted-foreground max-w-md mx-auto">
                      Ne vous découragez pas ! L'amour peut surmonter tous les obstacles.
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
              <Button
                onClick={onNewTest}
                size="lg"
                className="px-8 h-12 bg-gradient-to-r from-primary to-secondary hover-elevate active-elevate-2"
                data-testid="button-new-test"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Nouveau Test
              </Button>
              
              <Button
                onClick={onViewHistory}
                variant="outline"
                size="lg"
                className="px-8 h-12 hover-elevate active-elevate-2"
                data-testid="button-view-history"
              >
                <History className="w-5 h-5 mr-2" />
                Voir l'Historique
              </Button>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-sm text-muted-foreground" data-testid="text-disclaimer">
          Ce test est à but divertissant uniquement. Les résultats sont générés aléatoirement.
        </p>
      </div>
    </div>
  );
}
