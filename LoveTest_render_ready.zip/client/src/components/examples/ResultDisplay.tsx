import { useState } from "react";
import ResultDisplay from "../ResultDisplay";
import { Button } from "@/components/ui/button";

export default function ResultDisplayExample() {
  const [result, setResult] = useState<"accepted" | "refused">("accepted");

  return (
    <div className="space-y-4">
      <div className="flex gap-4 justify-center p-4">
        <Button onClick={() => setResult("accepted")} variant={result === "accepted" ? "default" : "outline"}>
          Show Accepted
        </Button>
        <Button onClick={() => setResult("refused")} variant={result === "refused" ? "default" : "outline"}>
          Show Refused
        </Button>
      </div>
      <ResultDisplay
        result={result}
        maleFirstName="Thomas"
        femaleFirstName="Sophie"
        onNewTest={() => console.log("New test clicked")}
        onViewHistory={() => console.log("View history clicked")}
      />
    </div>
  );
}
