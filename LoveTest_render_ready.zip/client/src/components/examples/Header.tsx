import Header from "../Header";

export default function HeaderExample() {
  return (
    <div>
      <Header
        userName="Marie Dupont"
        userEmail="marie.dupont@example.com"
        onLogout={() => console.log("Logout clicked")}
        onViewProfile={() => console.log("View profile clicked")}
        onViewHistory={() => console.log("View history clicked")}
      />
      <div className="p-8 text-center">
        <p className="text-muted-foreground">Header component example</p>
      </div>
    </div>
  );
}
