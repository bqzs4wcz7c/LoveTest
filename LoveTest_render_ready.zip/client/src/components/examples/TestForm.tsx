import TestForm from "../TestForm";

export default function TestFormExample() {
  const handleSubmit = (data: any) => {
    console.log("Test submitted:", data);
  };

  return <TestForm onSubmit={handleSubmit} />;
}
