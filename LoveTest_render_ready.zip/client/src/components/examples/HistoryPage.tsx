import HistoryPage from "../HistoryPage";

const mockResults = [
  {
    id: "1",
    maleFirstName: "Thomas",
    femaleFirstName: "Sophie",
    result: "accepted" as const,
    date: "15 novembre 2025"
  },
  {
    id: "2",
    maleFirstName: "Lucas",
    femaleFirstName: "Emma",
    result: "refused" as const,
    date: "12 novembre 2025"
  },
  {
    id: "3",
    maleFirstName: "Antoine",
    femaleFirstName: "Chloé",
    result: "accepted" as const,
    date: "8 novembre 2025"
  },
  {
    id: "4",
    maleFirstName: "Hugo",
    femaleFirstName: "Léa",
    result: "accepted" as const,
    date: "5 novembre 2025"
  },
  {
    id: "5",
    maleFirstName: "Nathan",
    femaleFirstName: "Camille",
    result: "refused" as const,
    date: "2 novembre 2025"
  }
];

export default function HistoryPageExample() {
  return (
    <HistoryPage
      results={mockResults}
      onBack={() => console.log("Back clicked")}
      onViewResult={(id) => console.log("View result:", id)}
    />
  );
}
