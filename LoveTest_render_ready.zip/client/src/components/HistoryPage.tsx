import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Calendar, ArrowLeft } from "lucide-react";

interface TestResult {
  id: string;
  maleFirstName: string;
  femaleFirstName: string;
  result: "accepted" | "refused";
  date: string;
}

interface HistoryPageProps {
  results: TestResult[];
  onBack: () => void;
  onViewResult: (id: string) => void;
}

export default function HistoryPage({ results, onBack, onViewResult }: HistoryPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/20 to-background">
      <div className="container max-w-6xl mx-auto p-6 space-y-8">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={onBack}
            className="hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Retour
          </Button>
        </div>

        <div className="space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent" data-testid="text-history-title">
            Historique des Tests
          </h1>
          <p className="text-muted-foreground" data-testid="text-history-subtitle">
            Consultez tous vos tests de compatibilité passés
          </p>
        </div>

        {results.length === 0 ? (
          <Card className="p-12">
            <CardContent className="text-center space-y-4">
              <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center">
                <Calendar className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold" data-testid="text-empty-state">
                Aucun test effectué
              </h3>
              <p className="text-muted-foreground">
                Vous n'avez pas encore effectué de test de compatibilité.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {results.map((test) => (
              <Card
                key={test.id}
                className="hover-elevate active-elevate-2 cursor-pointer transition-all"
                onClick={() => onViewResult(test.id)}
                data-testid={`card-test-${test.id}`}
              >
                <CardHeader className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-lg font-semibold line-clamp-1" data-testid={`text-names-${test.id}`}>
                      {test.maleFirstName} & {test.femaleFirstName}
                    </CardTitle>
                    {test.result === "accepted" ? (
                      <Badge className="bg-green-100 dark:bg-green-950 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-950" data-testid={`badge-result-${test.id}`}>
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Accepté
                      </Badge>
                    ) : (
                      <Badge className="bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-950" data-testid={`badge-result-${test.id}`}>
                        <XCircle className="w-3 h-3 mr-1" />
                        Refusé
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span data-testid={`text-date-${test.id}`}>{test.date}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
