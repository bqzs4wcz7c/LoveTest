# Design Guidelines: Couple Compatibility Test Application

## Design Approach
**Reference-Based Approach**: Drawing inspiration from dating platforms (Tinder, Bumble, OkCupid) combined with quiz/personality test interfaces. Focus on romantic, approachable aesthetic while maintaining professional credibility.

## Color Palette (User-Specified)
- **Primary**: Rose (#FF69B4, #FFB6C1 variations)
- **Secondary**: Violet/Purple (#8B5CF6, #A78BFA, #DDD6FE)
- **Accent**: Red (#EF4444, #F87171 for refuse states)
- **Success**: Green (#10B981, #34D399 for accept states)
- **Base**: White (#FFFFFF) with soft off-white backgrounds (#FDFCFC, #FFF5F7)
- **Gradient Combinations**: Rose-to-violet, violet-to-pink for headers and accent elements

## Typography
- **Primary Font**: 'Poppins' (Google Fonts) - modern, rounded, friendly
- **Secondary Font**: 'Inter' (Google Fonts) - clean for body text
- **Hierarchy**:
  - Hero Headlines: 3xl to 5xl, font-bold (Poppins)
  - Section Titles: 2xl to 3xl, font-semibold
  - Form Labels: sm to base, font-medium
  - Body Text: base, font-normal (Inter)
  - Results Display: 4xl to 6xl, font-extrabold for ACCEPTÉ/REFUSÉ

## Layout System
**Spacing Units**: Tailwind units of 4, 6, 8, 12, 16 for consistent rhythm
- Section padding: py-16 to py-24
- Component gaps: gap-6 to gap-8
- Card padding: p-6 to p-8
- Form field spacing: space-y-4

## Component Library

### Authentication Page
- **Hero Section**: Full-viewport romantic gradient background (rose-to-violet), centered content
- **Login Card**: Floating white card (max-w-md) with soft shadow, rounded-2xl corners
- **Google OAuth Button**: White background, Google colors, icon + text, hover lift effect
- **Divider**: "OU" text with horizontal lines, subtle gray
- **Email/Password Form**: Stacked inputs with focus states (violet ring), labels above inputs
- **CTA Buttons**: Gradient backgrounds (rose-to-violet), white text, rounded-lg, font-semibold

### Dashboard/Test Interface
- **Header**: White background with subtle shadow, logo left, user profile/logout right
- **Two-Column Form Layout**: 
  - Desktop: Side-by-side columns (grid-cols-2) with visual separator (heart icon or vertical line)
  - Mobile: Stacked columns (grid-cols-1)
  - Each column: Soft background (rose tint for female, violet tint for male), rounded-xl, p-8
- **Input Fields**: 
  - White backgrounds, rounded-lg borders
  - Labels: font-medium, violet color
  - Focus states: Violet ring-2
  - Dropdowns for month selection with custom styling
- **Submit Button**: Centered below columns, large (px-12 py-4), gradient, pulsing animation on hover

### Results Display
- **Results Card**: Centered, max-w-2xl, white background, dramatic shadow
- **Status Display**: 
  - "ACCEPTÉ": text-6xl font-extrabold text-green-600, with checkmark icon
  - "REFUSÉ": text-6xl font-extrabold text-red-600, with X icon
- **Compatibility Score**: Large percentage (if shown), circular progress indicator
- **Details Section**: Smaller text explaining the result, subtle background
- **Action Buttons**: "Nouveau Test" prominent, "Voir Historique" secondary

### History Page
- **Card Grid**: Grid of past tests (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- **Test Cards**: White backgrounds, hover lift, includes date, names, result badge (green/red)
- **Empty State**: Centered illustration placeholder + encouraging text

## Images
- **Login Hero Background**: Romantic gradient overlay over subtle heart pattern or bokeh effect
- **Dashboard Background**: Very subtle pattern (tiny hearts or abstract romantic shapes), barely visible
- **Results Page**: Celebratory imagery for ACCEPTÉ (confetti, hearts), sympathetic for REFUSÉ
- No large hero images needed - focus on gradients, patterns, and iconography

## Navigation
- **Minimal Top Bar**: Logo, app name, user avatar dropdown
- **Mobile**: Hamburger menu for small screens
- **Protected Routes**: Redirect to login with romantic loading transition

## Animations (Minimal)
- **Page Transitions**: Soft fade-ins (300ms)
- **Button Hovers**: Slight lift (translateY -2px) with shadow increase
- **Results Reveal**: Scale-up animation for ACCEPTÉ/REFUSÉ text (500ms ease-out)
- **Form Submission**: Loading spinner with heart pulse animation

## Accessibility
- High contrast for ACCEPTÉ (green) and REFUSÉ (red) text
- All form inputs with clear labels and focus indicators
- ARIA labels for icon-only buttons
- Keyboard navigation support throughout

## Romantic Design Elements
- **Hearts**: Use as decorative elements, dividers, bullet points
- **Rounded Corners**: Everything rounded-lg or rounded-xl minimum
- **Soft Shadows**: shadow-lg to shadow-2xl for depth
- **Gradients**: Liberal use of rose-to-violet gradients for accents
- **Glow Effects**: Subtle glow on interactive elements (ring-violet-200)