# Couple Compatibility Test Application

## Overview

A romantic web application that allows couples to test their compatibility through a fun, quiz-based interface. Users authenticate via Google OAuth (Replit Auth), fill out a two-column form with male and female partner information (first name, age, birth month), and receive instant "ACCEPTÉ" (accepted) or "REFUSÉ" (refused) results. The application maintains a history of all test results for authenticated users.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript, utilizing Vite as the build tool and development server.

**Routing**: Wouter for lightweight client-side routing with route protection based on authentication state.

**UI Component Library**: Shadcn/ui (New York style) built on Radix UI primitives with Tailwind CSS for styling. Components follow a romantic aesthetic with rose-to-violet gradients, rounded corners, and soft shadows.

**State Management**: 
- TanStack Query (React Query) for server state management, data fetching, and cache management
- React hooks for local component state
- Authentication state handled through custom `useAuth` hook

**Styling System**:
- Tailwind CSS with custom configuration for romantic color palette (rose primary, violet secondary)
- Custom CSS variables for theme colors, elevations, and shadows
- Google Fonts integration (Poppins for headings, Inter for body text)
- Responsive design with mobile-first approach

**Key Design Decisions**:
- Two-column form layout for male/female partner information (responsive to single column on mobile)
- Gradient backgrounds and romantic color scheme throughout
- Test results displayed as large, bold "ACCEPTÉ" or "REFUSÉ" with visual indicators
- Protected routes requiring authentication to access test and history pages

### Backend Architecture

**Runtime**: Node.js with Express.js web framework

**Development/Production Split**: 
- Development mode uses Vite middleware for HMR and SSR of React application
- Production mode serves pre-built static assets from dist folder
- Separate entry points (`index-dev.ts` and `index-prod.ts`) for each environment

**API Structure**:
- RESTful API endpoints under `/api` prefix
- `/api/auth/user` - Get authenticated user information
- `/api/test/submit` - Submit compatibility test results
- `/api/test/history` - Retrieve user's test history
- `/api/test/:id` - Get specific test result by ID

**Request Validation**: Zod schemas with drizzle-zod integration for type-safe validation of incoming requests.

**Error Handling**: Centralized error handling with formatted responses, 401 detection for expired sessions.

### Authentication & Authorization

**Provider**: Replit Auth using OpenID Connect (OIDC) protocol

**Session Management**:
- Express sessions with PostgreSQL session store (`connect-pg-simple`)
- Session persistence in database `sessions` table
- 7-day session TTL with secure, httpOnly cookies
- Passport.js strategy for OIDC authentication flow

**Authorization Pattern**:
- `isAuthenticated` middleware on protected API routes
- Client-side route guards in React router
- User claims stored in session with access/refresh tokens
- Automatic token refresh handled by OIDC client

**Design Rationale**: Replit Auth provides seamless authentication in the Replit environment with minimal configuration, leveraging industry-standard OIDC protocol for security.

### Data Storage

**ORM**: Drizzle ORM with TypeScript-first schema definitions

**Database Driver**: Neon serverless PostgreSQL driver for connection pooling and serverless compatibility

**Schema Design**:

1. **users table**: Stores user profiles synced from Replit Auth
   - Primary key: UUID (auto-generated)
   - Fields: email, firstName, lastName, profileImageUrl
   - Timestamps: createdAt, updatedAt
   - Upsert pattern on authentication to sync user data

2. **testResults table**: Stores compatibility test submissions
   - Primary key: UUID (auto-generated)
   - Foreign key: userId references users table
   - Fields: maleFirstName, maleAge, maleMonth, femaleFirstName, femaleAge, femaleMonth, result
   - Timestamp: createdAt
   - Result field stores "accepted" or "refused"

3. **sessions table**: PostgreSQL session storage for express-session
   - Primary key: sid (session ID)
   - Fields: sess (JSON session data), expire (expiration timestamp)
   - Indexed on expire column for efficient cleanup

**Migration Strategy**: Drizzle Kit for schema migrations with `db:push` script for development.

**Compatibility Algorithm**: Simple deterministic calculation based on sum of name lengths, ages, and birth month string lengths. Even sum = "accepted", odd sum = "refused". This ensures consistent results while maintaining the fun, non-serious nature of the application.

### External Dependencies

**Third-Party Services**:
- **Replit Auth (OIDC)**: Primary authentication provider
  - Endpoint: `ISSUER_URL` environment variable (defaults to replit.com/oidc)
  - Client credentials: `REPL_ID` environment variable
  - Handles OAuth flow, token management, and user profile

**Database**:
- **PostgreSQL** (via Neon serverless): Primary data store
  - Connection: `DATABASE_URL` environment variable
  - Serverless driver enables edge/serverless deployment
  - Connection pooling handled by Neon driver

**Environment Configuration**:
- `DATABASE_URL`: PostgreSQL connection string (required)
- `SESSION_SECRET`: Secret for signing session cookies (required)
- `REPL_ID`: Replit application identifier for OIDC (required in Replit environment)
- `ISSUER_URL`: OIDC issuer URL (optional, defaults to Replit's OIDC endpoint)
- `NODE_ENV`: Environment flag (development/production)

**UI Dependencies**:
- Radix UI primitives for accessible, unstyled UI components
- Lucide React for icons
- React Icons (specifically Google icon for auth button)
- Tailwind CSS for utility-first styling
- Class Variance Authority for component variant management

**Development Tools**:
- Vite plugins for Replit integration (cartographer, dev banner, runtime error modal)
- TypeScript for type safety across frontend and backend
- ESBuild for production backend bundling