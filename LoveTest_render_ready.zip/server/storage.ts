import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { users, testResults, type User, type UpsertUser, type TestResult, type InsertTestResult } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  createTestResult(testResult: InsertTestResult): Promise<TestResult>;
  getTestResultsByUserId(userId: string): Promise<TestResult[]>;
  getTestResultById(id: string): Promise<TestResult | undefined>;
}

export class DbStorage implements IStorage {
  private db;

  constructor() {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    this.db = drizzle(pool);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await this.db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async createTestResult(insertTestResult: InsertTestResult): Promise<TestResult> {
    const result = await this.db.insert(testResults).values(insertTestResult).returning();
    return result[0];
  }

  async getTestResultsByUserId(userId: string): Promise<TestResult[]> {
    const results = await this.db
      .select()
      .from(testResults)
      .where(eq(testResults.userId, userId))
      .orderBy(desc(testResults.createdAt));
    return results;
  }

  async getTestResultById(id: string): Promise<TestResult | undefined> {
    const result = await this.db.select().from(testResults).where(eq(testResults.id, id));
    return result[0];
  }
}

export const storage = new DbStorage();
