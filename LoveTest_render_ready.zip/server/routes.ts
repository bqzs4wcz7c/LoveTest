import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTestResultSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  await setupAuth(app);

  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post('/api/test/submit', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const validationResult = insertTestResultSchema.safeParse({
        ...req.body,
        userId,
      });

      if (!validationResult.success) {
        const errorMessage = fromZodError(validationResult.error).toString();
        return res.status(400).json({ message: errorMessage });
      }

      const testResult = await storage.createTestResult(validationResult.data);
      res.json(testResult);
    } catch (error) {
      console.error("Error submitting test:", error);
      res.status(500).json({ message: "Failed to submit test" });
    }
  });

  app.get('/api/test/history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const results = await storage.getTestResultsByUserId(userId);
      res.json(results);
    } catch (error) {
      console.error("Error fetching history:", error);
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  app.get('/api/test/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const testResult = await storage.getTestResultById(req.params.id);
      
      if (!testResult) {
        return res.status(404).json({ message: "Test result not found" });
      }

      if (testResult.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      res.json(testResult);
    } catch (error) {
      console.error("Error fetching test result:", error);
      res.status(500).json({ message: "Failed to fetch test result" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
